

<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="">

<head>
	<meta charset="UTF-8" />
	<link type="text/css" rel="stylesheet" href="css/style_.css">
	<title>Result</title>
</head>

<body>

	<h1 class="Title">UNIT CONVERTER
		<button class="Persistence" type="button">
			<a href="/persistence">PERSISTENCE</a>
		</button>
	</h1>

	<div class="Resultado_final">

		<?php echo e($resultado); ?>



	</div>

</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lframework\resources\views/result.blade.php ENDPATH**/ ?>