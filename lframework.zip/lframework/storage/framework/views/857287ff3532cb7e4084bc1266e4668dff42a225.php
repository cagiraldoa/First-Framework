

<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="">

<head>
    <meta charset="UTF-8" />
    <link type="text/css" rel="stylesheet" href="css/style_.css">
    <title>Result</title>
</head>

<body>

    <h1 class="Title2">YOUR PREFERENCES</h1>

    <div class="Tb2">
    <table class="Tabla">
        <tr>
            <td>MILIMETERS</td>
            <td><?php echo e($milimeters); ?></td>
        </tr>
        <tr>
            <td>CENTIMETERS</td>
            <td><?php echo e($centimeters); ?></td>
        </tr>
        <tr>
            <td>DECIMETERS</td>
            <td><?php echo e($decimeters); ?></td>
        </tr>
        <tr>
            <td>METERS</td>
            <td><?php echo e($meters); ?></td>
        </tr>
        <tr>
            <td>DECAMETERS</td>
            <td><?php echo e($decameters); ?></td>
        </tr>
        <tr>
            <td>HECTOMETERS</td>
            <td><?php echo e($hectometers); ?></td>
        </tr>
        <tr>
            <td>KILOMETERS</td>
            <td><?php echo e($kilometers); ?></td>
        </tr>
    </table>
    </div>

</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lframework\resources\views/persistence.blade.php ENDPATH**/ ?>